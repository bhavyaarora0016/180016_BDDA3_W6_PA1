This program analyzes the MovieLens data collected by the GroupLens Research Project at the University of Minnesota. http://grouplens.org/datasets/movielens.

The input file contains userid,movie,rating

We build A Mahout-based collaborative filtering engine takes users' preferences for items ("tastes") and returns 10 movie recommendations for each user. The output file is in the format userid [itemID1:score1, itemID2:score2, ...]

